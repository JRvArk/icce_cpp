#include "calculator/calculator.h"

int main()
{
    Calculator::run();
}