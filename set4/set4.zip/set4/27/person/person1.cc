#include "person.ih"

Person::Person()
{
    d_mass = 0;
}
