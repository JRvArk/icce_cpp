#include "../person.ih"

string const &Person::phone() const
{
    return d_phone;
}
