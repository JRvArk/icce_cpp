#include "../30/calculator/calculator.h"

int main()
{
    Calculator calculator;
    calculator.run();
}