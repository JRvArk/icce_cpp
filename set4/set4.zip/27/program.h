#ifndef PROGRAM_H
#define PROGRAM_H

#include <vector>

#include "../26/person/person.h"

void readPersons(Person *persons, size_t amt);
void writePersons(Person const *persons, size_t amt);

#endif