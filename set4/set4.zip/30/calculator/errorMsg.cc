#include "calculator.ih"

void Calculator::errorMsg()
{
    cout << "Provide a correct statement, see Usage info. \n";
}