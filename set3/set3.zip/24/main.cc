#include <string>
#include <iostream>

#include "utils/utils.h"

using namespace std;

int main(int argc, char *argv[])
{
    callValue(argv[0]);
    callRef(argv[0]);
}
