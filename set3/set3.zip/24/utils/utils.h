#ifndef UTILS_H_
#define UTILS_H_

void callRef(std::string const &prog);

void callValue(std::string const &prog);

void fun2(std::string const &str);

void fun(std::string str);

#endif
