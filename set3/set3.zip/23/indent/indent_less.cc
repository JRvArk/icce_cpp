#include "indent.ih"

void indent_less()
{	
	const char *command = "dec";
	indent_depth(command);
}
