#include "indent.ih"

void indent_more()
{
	const char* command = "inc";
	indent_depth(command);
}
