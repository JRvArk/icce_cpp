#ifndef MAIN_INCLUDED
#define MAIN_INCLUDED

bool hasDoubleArgument(int argc, char **argv);

int sum(int argc, char **argv);                                   //1
double sum(int argc, char **argv, double anyDoubleValue);         //2

#endif
