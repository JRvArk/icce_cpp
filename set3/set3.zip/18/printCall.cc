#include "main.ih"

void printCall(size_t nr, string value)
{
        cout << "Argument number: " << nr << '\n'
             << "Its value:       " << value << '\n';
}
