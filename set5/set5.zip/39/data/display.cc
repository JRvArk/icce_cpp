#include "dataImpl.ih"

void DataImpl::display() const
{
    cout << "value is: " << d_value << '\n';
}
