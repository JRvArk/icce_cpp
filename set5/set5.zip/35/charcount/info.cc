#include "charcount.ih"

CharCount::CharInfo const CharCount::info()
{
    return d_charInfo;
}