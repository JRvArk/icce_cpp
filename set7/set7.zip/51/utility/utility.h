#ifndef SET7_51_UTILITY_UTILITY_H
#define SET7_51_UTILITY_UTILITY_H

#include <string>

using namespace std;

void convert(const string &name);
string lowercase(const string &input);

#endif