#ifndef SET7_51_UTILITY_UTILITY_H
#define SET7_51_UTILITY_UTILITY_H

#include <string> //JB: BH: overkill

using namespace std; // JB: Don't force a namespace on the user.
//JB: (This is a public header file, isn't it?)

void convert(const string &name);
string lowercase(const string &input);

#endif
