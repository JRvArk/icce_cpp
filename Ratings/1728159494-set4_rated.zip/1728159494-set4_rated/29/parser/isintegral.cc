#include "parser.ih"

bool Parser::isIntegral()
{
    return d_integral;
}