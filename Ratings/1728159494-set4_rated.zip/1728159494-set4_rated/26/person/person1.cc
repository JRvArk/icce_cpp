// AI: This wouldn't have been necessary if you initialised
// AI: The data member 'd_mass' to 0 in the class definition
#include "person.ih"

Person::Person()
{
    d_mass = 0;
}
