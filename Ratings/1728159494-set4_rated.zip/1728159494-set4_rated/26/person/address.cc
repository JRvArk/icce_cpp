#include "person.ih"

string const &Person::address() const
{
    return d_address;
}
