#include "person.ih"

string const &Person::name() const
{
    return d_name;
}
