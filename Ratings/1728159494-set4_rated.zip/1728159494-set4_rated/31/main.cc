// AI: 0

// AI: You can directly include from the previous exercise:
// AI: e.g. #include "../30/calculator/calculator.h"
#include "calculator/calculator.h"

int main()
{
    // AI: I don't understand why you don't create a Calculator object
    // AI: And then run it.
    // AI: You are directly calling the run function of the Calculator class
    // AI: I suggest revisiting the lecture about classes (week 4).

    // AI: A correct example would be:
    // AI: Calculator calculator;
    // AI: calculator.run();
    Calculator::run();
}