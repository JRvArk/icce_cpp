// AI: I think this exercise would benefit from a fair amount of restructuring
// AI: 0

#include "calculator/calculator.h"

int main()
{
    Calculator::run();
}