// AI: I really don't see the point of this
// AI: Why make them static in the class?
#include "calculator.ih"

std::istringstream Calculator::s_iss;
double Calculator::s_num1;
bool Calculator::s_int1;
enum Operator Calculator::s_op;
double Calculator::s_num2;
bool Calculator::s_int2;